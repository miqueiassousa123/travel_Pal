const savedInfo = document.querySelector(".history");
showStoredInfo();

// RETRIEVE DATA FROM LOCAL STORAGE AND DISPLAY IT
function showStoredInfo() {
    let storageData = [];
    storageData = JSON.parse(localStorage.getItem('storage'));

    // ITERATE DATA AND DISPLAY IT ON THE SCREEN
    for (let i = storageData.length - 1; i >= 0; i--) {
        let date = document.createElement('strong');
        date.innerHTML = "Date: " + storageData[i].date;
        savedInfo.appendChild(date);
        savedInfo.appendChild(document.createElement('br'));
        let location = document.createElement('strong');
        location.innerHTML = "Location: " + storageData[i].location;
        savedInfo.appendChild(location);
        savedInfo.appendChild(document.createElement('br'));

        // CHECK TO SEE IF WE SAVED ALSO WEATHER INFORMATION
        if (storageData[i].weather !== undefined && storageData[i].weather !== null) {
            if (storageData[i].weather.temperature !== undefined) {
                let weather = document.createElement('strong');
                weather.innerHTML = "Weather: " + storageData[i].weather.temperature.value + " " + storageData[i].weather.description;
                savedInfo.appendChild(weather);
            }
        }
        savedInfo.appendChild(document.createElement('br'));
        savedInfo.appendChild(document.createElement('br'));
    }
}

