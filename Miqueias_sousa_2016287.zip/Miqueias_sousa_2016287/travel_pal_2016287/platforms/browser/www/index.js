// SELECT ELEMENTS Constant declaration that gets fetch the placeholders from index html

// SELECT ELEMENTS
const iconElement = document.querySelector(".weather-icon");
const tempElement = document.querySelector(".temperature-value p");
const descElement = document.querySelector(".temperature-description p");
const locationElement = document.querySelector(".location p");
const notificationElement = document.querySelector(".notification");
// Ends here Query selector

// App data

const weather = {};

weather.temperature = {
    unit: "celsius"
};

// APP CONSTS AND VARS THese are constants because they are not going to change on runtime 

const KELVIN = 273;
// API KEY
const key = "82005d27a116c2880c8f0fcb866998a0";

// CHECK IF BROWSER SUPPORTS GEOLOCATION Checker 
if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(setPosition, showError);
} else {
    notificationElement.style.display = "block";
    notificationElement.innerHTML = "<p>Browser doesn't Support Geolocation</p>";
}

// SET USER'S POSITION FROM DEVICE (LAT and LONG)
function setPosition(position) {
    let latitude = position.coords.latitude; // These are predefined attributes from phonegap after getting location permissions
    let longitude = position.coords.longitude;// These will be taken from the device
    console.log(" Lat:" + latitude + " long :" + longitude)
    getWeather(latitude, longitude);// Passinglat and long to the weather function

}

// SHOW ERROR WHEN THERE IS AN ISSUE WITH GEOLOCATION SERVICE
function showError(error) {
    notificationElement.style.display = "block";
    notificationElement.innerHTML = `<p> ${error.message} </p>`;
}

// GET WEATHER FROM API PROVIDER
function getWeather(latitude, longitude) { // The lat and long taken from device is passed to the get weather functions which will pass it to the api
    let api = `http://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${key}`; // API here key is already set as constant

    fetch(api)
        .then(function (response) { // Fetches the data from api as an object
            let data = response.json();
            console.log("data", data);
            return data;

        })
        .then(function (data) {
            weather.temperature.value = Math.floor(data.main.temp - KELVIN); // Formula to conver the data into figures (Some maths)
            weather.description = data.weather[0].description;
            weather.iconId = data.weather[0].icon;
            weather.city = data.name; // Name from object City
            weather.country = data.sys.country; // country name from api object
        })
        .then(function () {
            displayWeather();
        });
}
// GET CURRENT DATE AND TIME WHEN SAVING INFO
function getDate() {
    var currentdate = new Date();
    return currentdate.getHours() + ":"
        + currentdate.getMinutes() + ":"
        + currentdate.getSeconds() + " "
        + currentdate.getDay() + "/"
        + currentdate.getMonth() + "/"
        + currentdate.getFullYear();
}

// Display weather
function displayWeather() {

    locationElement.innerHTML = `${weather.city}, ${weather.country}`; // attributes assigned above are shown here as an inner HTml simple JS

}
function displayTime() {
    deviceTime.innerHTML = `${time}`; // Display time here in this function
}

function myLocation() {

}
function myLocation2() {
    document.getElementById("demo2").innerHTML = `${longitude}, ${latitude}`; // Location display
}

// C to F conversion
function celsiusToFahrenheit(temperature) {
    return (temperature * 9) / 5 + 32;
}

// This is going to send the request to the device and get the boolean in return if true then device ready 
document.addEventListener("deviceready", onDeviceReady, true); // Device listener
function onDeviceReady()  // if the device is ready
{

}
function fail(error) {
    console.log("Error: " + error.code);
}

// SAVE DATA IN LOCAL STORAGE
function saveInfo() {
    var storageData = [];
    storageData = JSON.parse(localStorage.getItem('storage'));

    //CREATE A VARIABLE TO STORE DATA
    var test = {
        location: `${weather.city}, ${weather.country}`,
        date: getDate(),
        weather:  JSON.parse(localStorage.getItem('weather'))
    };
    storageData.push(test);
    localStorage.setItem('storage', JSON.stringify(storageData));
    alert("Info saved successfully");
}

navigator.geolocation.getCurrentPosition(onSuccess, onError);

function onSuccess(position) {
    var current_lat = position.coords.latitude;
    var current_lng = position.coords.longitude;
    var secheltLoc = new google.maps.LatLng(current_lat, current_lng);

    var myMapOptions = {
        zoom: 16
        , center: secheltLoc
        , mapTypeId: google.maps.MapTypeId.HYBRID
    };
    var theMap = new google.maps.Map(document.getElementById("map_canvas"), myMapOptions);
    var image = "map_pin.png"
    var marker = new google.maps.Marker({
        map: theMap,
        draggable: false,
        position: new google.maps.LatLng(latitude, longitude),
        visible: true,
        icon: image,
        title: 'Title' // Title
    });

    var myOptions = {
        content: ""
        , disableAutoPan: false
        , maxWidth: 0
        , pixelOffset: new google.maps.Size(-140, -110)
        , pixelOffset: new google.maps.Size(140, 110)
        , zIndex: null
        , boxStyle: {
            background: "url('tipbox.gif') no-repeat"
            , opacity: 0.90
        }
        , closeBoxMargin: "10px 2px 2px 2px"
        , closeBoxURL: "http://www.google.com/intl/en_us/mapfiles/close.gif"
        , infoBoxClearance: new google.maps.Size(1, 1)
        , isHidden: false
        , pane: "floatPane"
        , enableEventPropagation: false
    };

    var contentString = '<div class="map_anotaion_title">${weather.city}, ${weather.country}</div>'; //Address on pin click

    var infowindow = new google.maps.InfoWindow({
        content: contentString
    });
    infowindow.open(theMap, marker);
    google.maps.event.addListener(marker, "click", function (e) {
        infowindow.open(theMap, marker);
    });
}

function onError(error) {
    alert(error);
}
// SELECT ELEMENTS Constant declaration that gets fetch the placeholders from index html 

// SELECT ELEMENTS TO THE CONVERTION PART

const from_currencyEl = document.getElementById('from_currency');
const from_ammountEl = document.getElementById('from_ammount');
const to_currencyEl = document.getElementById('to_currency');
const to_ammountEl = document.getElementById('to_ammount');
const rateEl = document.getElementById('rate');
const exchange = document.getElementById('exchange');

from_currencyEl.addEventListener('change', calculate);
from_ammountEl.addEventListener('input', calculate);
to_currencyEl.addEventListener('change', calculate);
to_ammountEl.addEventListener('input', calculate);

exchange.addEventListener('click', () => {
    const temp = from_currencyEl.value;
    from_currencyEl.value = to_currencyEl.value;
    to_currencyEl.value = temp;
    calculate();
});

function calculate() {
    const from_currency = from_currencyEl.value;
    const to_currency = to_currencyEl.value;

    fetch(`https://api.exchangerate-api.com/v4/latest/${from_currency}`)//get the data from the api
        .then(res => res.json())
        .then(res => {
            const rate = res.rates[to_currency];
            rateEl.innerText = `1 ${from_currency} = ${rate} ${to_currency}`
            to_ammountEl.value = (from_ammountEl.value * rate).toFixed(3);
        })
}

calculate();